import mondaySdk from "monday-sdk-js";

const monday = mondaySdk();

export class MondayService {
  async getUserContext(): Promise<Record<string, unknown>> {
    return new Promise((resolve, reject) => {
      monday.listen("context", (res: { data: object }) => {
        if (res.data) {
          resolve(res.data as Record<string, unknown>);
        } else {
          reject(new Error("Failed to get user context"));
        }
      });
    });
  }

  async getBoardInfo(): Promise<{ boardId: number; boardName: string }> {
    return new Promise((resolve, reject) => {
      monday.listen("context", (res: { data: object }) => {
        const data = res.data as { boardId?: number; boardName?: string };
        if (data?.boardId) {
          resolve({
            boardId: data.boardId,
            boardName: data.boardName || "Unknown Board",
          });
        } else {
          reject(new Error("Board context not available"));
        }
      });
    });
  }

  notifyUser(
    message: string,
    type: "success" | "error" | "info" = "info",
  ): void {
    monday.execute("notice", { message, type });
  }
}

export const mondayService = new MondayService();
