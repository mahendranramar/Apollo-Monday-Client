import axios, { AxiosInstance, AxiosError } from "axios";
import { API_PATH, ROOT_DOMAIN } from "../constants";
import type { AuthState, BillingInfo, Connection, Workflow } from "../types";

export interface KonnectifyClientConfig {
  domain: string;
  token?: string;
}

export class KonnectifyClient {
  private axiosInstance: AxiosInstance;
  private config: KonnectifyClientConfig;

  constructor(config: KonnectifyClientConfig) {
    this.config = config;
    this.axiosInstance = axios.create({
      baseURL: `https://f1a6e-service-35433930-e3294c23.us.monday.app/api`,
      headers: { "Content-Type": "application/json" },
    });

    if (config.token) {
      this.setAuthToken(config.token);
    }
  }

  get domain(): string {
    return this.config.domain;
  }

  setAuthToken(token: string): void {
    this.config.token = token;
  }

  async registerUser(
    email: string,
    password: string,
    name: string,
    orgId: string,
    projectId: string,
    website?: string,
  ): Promise<AuthState> {
    const response = await axios.post<{ accessToken: string }>(
      // `https://${this.config.domain}${ROOT_DOMAIN}${API_PATH}/auth/register/service`,
      `https://f1a6e-service-35433930-e3294c23.us.monday.app/api/user/register`,
      {
        domain: `${this.config.domain}${ROOT_DOMAIN}`,
        email,
        password,
        name,
        website: website || "",
        orgId,
        projectId,
      },
    );
    return { accessToken: response.data.accessToken, email };
  }

  async verifyEmail(){
    await this.axiosInstance.post("/user/verify-email", {
      domain: this.config.domain,
      token: this.config.token
    });
  }

  async getBootstrapToken(email: string, password: string): Promise<string> {
    const response = await axios.post<{ token: string }>(
      // `https://${this.config.domain}${ROOT_DOMAIN}${API_PATH}/auth/bootstrap-token`,
      `https://f1a6e-service-35433930-e3294c23.us.monday.app/api/user/auth/bootstrap-token`,
      { email, password, domain:this.config.domain },
    );
    // The response has both `token` (120s bootstrap token for iframes) and
    // `accessToken` (long-lived service token). We only want the bootstrap token here.
    return response.data.token;
  }

  async login(
    email: string,
    password: string,
    orgId: string,
  ): Promise<AuthState> {
    const response = await axios.post<{ accessToken: string }>(
      // `https://${this.config.domain}${ROOT_DOMAIN}${API_PATH}/auth/login/service`, { email, password, orgId },
      `https://f1a6e-service-35433930-e3294c23.us.monday.app/api/user/login`,
      { email, password, domain:this.config.domain },
    );
    console.log("login res", response.data);
    return { accessToken: response.data.accessToken, email };
  }

  async validateSession(): Promise<boolean> {
    try {
      // await this.axiosInstance.get("/sessions/me");
      await this.axiosInstance.post("/user/session", {
        domain: this.config.domain,
        token: this.config.token
      });
      return true;
    } catch {
      return false;
    }
  }

  async logout(): Promise<void> {
    try {
      // await this.axiosInstance.post("/auth/logout", {});
      await this.axiosInstance.post("/user/logout", {});
    } catch (error) {
      console.error("Logout error:", error);
    }
  }

  async installKonnectorFromTemplate(
    templateId: number,
  ): Promise<string | null> {
    // const response = await this.axiosInstance.post<{ konnectorId?: string }>(
    //   `/template-folders/${templateId}/install?skipConnection=true`,
    // );
    // return response.data?.konnectorId ?? null;
     const response = await this.axiosInstance.post<{
      message: string;
      connectorFolderId: string;
      connectors: {
      connectorId: string;
      connectorName: string;
      }[];
    }>(
      `/connector/template/install`, {templateId, token:this.config.token, domain:this.config.domain}
    );
    console.log("install", response);
    return response.data.connectors[0].connectorId
  }

  async listWorkflows(pageSize = 50, pageNumber = 1): Promise<Workflow[]> {
    // const response = await this.axiosInstance.get<{
    //   data?: { list?: Record<string, unknown>[] };
    //   list?: Record<string, unknown>[];
    // }>(`/konnectors?pageSize=${pageSize}&pageNumber=${pageNumber}`);
    const response = await this.axiosInstance.post<{
      data?: { list?: Record<string, unknown>[] };
      list?: Record<string, unknown>[];
    }>(`/connector/connectors?pageSize=${pageSize}&pageNumber=${pageNumber}`, {
      token:this.config.token, domain:this.config.domain
    });

    const items = response.data?.data?.list || response.data?.list || [];

    return items.map((item) => ({
      id: String(item.id),
      name: String(item.name ?? ""),
      enabled: item.status === "ACTIVE",
      createdAt: String(item.createdAt ?? new Date().toISOString()),
      description: item.description ? String(item.description) : undefined,
      status: item.status as Workflow["status"],
      lastModified: item.updatedAt ? String(item.updatedAt) : undefined,
      lastRun: item.lastRunAt ? String(item.lastRunAt) : undefined,
      appId: item.appId ? String(item.appId) : undefined,
    }));
  }

  async activateWorkflow(workflowId: string): Promise<void> {
    // await this.axiosInstance.post(`/konnectors/${workflowId}/ACTIVE`);
    await this.axiosInstance.post(`/connector/${workflowId}/activate`, {
      domain: this.config.domain,
      token: this.config.token
    });
  }

  async deactivateWorkflow(workflowId: string): Promise<void> {
    // await this.axiosInstance.post(`/konnectors/${workflowId}/INACTIVE`);
    await this.axiosInstance.post(`/connector/${workflowId}/deactivate`, {
      domain: this.config.domain,
      token: this.config.token
    });
  }

  async listConnections(pageSize = 50, pageNumber = 1): Promise<Connection[]> {
    // const response = await this.axiosInstance.get<{
    //   data?: { list?: Record<string, unknown>[] };
    //   list?: Record<string, unknown>[];
    // }>(`/connections?pageSize=${pageSize}&pageNumber=${pageNumber}`);
    const response = await this.axiosInstance.post<{
      data?: { list?: Record<string, unknown>[] };
      list?: Record<string, unknown>[];
    }>(`/connector/connections?pageSize=${pageSize}&pageNumber=${pageNumber}`, {
      token:this.config.token, domain:this.config.domain
    });

    const items = response.data?.data?.list || response.data?.list || [];

    return items.map((item) => ({
      id: String(item.id),
      appId: String(item.appId ?? ""),
      name: String(item.name ?? ""),
      data: (item.data as Record<string, unknown>) ?? {},
      status: item.status ? String(item.status) : "unknown",
      connectedUser: item.connectedUser
        ? String(item.connectedUser)
        : item.userEmail
          ? String(item.userEmail)
          : undefined,
      updatedAt: item.updatedAt ? String(item.updatedAt) : undefined,
      createdAt: item.createdAt ? String(item.createdAt) : undefined,
    }));
  }

  async createConnection(
    appId: string,
    name: string,
    data: Record<string, unknown>,
  ): Promise<Connection> {
    // const response = await this.axiosInstance.post<Connection>("/connections", {
    //   appId,
    //   name,
    //   data,
    // });
    const response = await this.axiosInstance.post<Connection>("/connector/connection", {
      appId,
      name,
      data,
      token: this.config.token,
      domain: this.config.domain
    });
    console.log("connection creation", response);
    return response.data;
  }

  async updateConnection(
    connectionId: string,
    appId: string,
    name: string,
    data: Record<string, unknown>,
  ): Promise<Connection> {
    // const response = await this.axiosInstance.put<Connection>(
    //   `/connections/${connectionId}`,
    //   {
    //     appId,
    //     name,
    //     data,
    //   },
    // );
    const response = await this.axiosInstance.post<Connection>(
      `/connector/connection/${connectionId}/update`,
      {
        appId,
        name,
        data,
        token: this.config.token,
        domain: this.config.domain
      },
    );
    console.log("update connecton", response);
    return response.data;
  }

  async editConnection(
    connectionId: string,
    appId: string,
    name: string,
    data: Record<string, unknown>,
  ): Promise<Connection> {
    // const response = await this.axiosInstance.patch<Connection>(
    //   `/connections/${connectionId}`,
    //   { appId, name, data },
    // );
    const response = await this.axiosInstance.patch<Connection>(
      `/connector/connection/${connectionId}/edit`,
      { appId, name, data, 
        token: this.config.token,
        domain: this.config.domain
      },
    );
    console.log("edit connection", response)
    return response.data;
  }

  async deleteConnection(connectionId: string): Promise<void> {
    // await this.axiosInstance.delete(`/connections/${connectionId}`);
    const response = await this.axiosInstance.post(`/connector/connection/${connectionId}/delete`, 
      { 
        token: this.config.token,
        domain: this.config.domain
      },
    )
    console.log("connection delete", response);
  }

  async getOAuthAuthUrl(
    appId: string,
    connectionName: string,
    instanceURL?: string,
  ): Promise<{ authUrl: string; state: string }> {
    // const response = await this.axiosInstance.post<{
    //   data: { authUrl: string; state: string };
    // }>(`/oauth/${appId}/auth-url`, {
    //   connectionName,
    //   data: { base_url: instanceURL },
    // });
    const response = await this.axiosInstance.post<{
      data: { authUrl: string; state: string };
    }>(`/connector/oauth/${appId}/auth-url`, {
      connectionName,
      token: this.config.token,
      domain: this.config.domain
    });
    console.log("auth url", response);
    return response.data.data;
  }

  async getBillingInfo(): Promise<BillingInfo> {
    // const response = await this.axiosInstance.get<{
    //   inTrial?: boolean;
    //   billing?: {
    //     plan?: string;
    //     billingCycle?: string;
    //     subscriptionEnd?: string;
    //     trialEnd?: string;
    //     status?: string;
    //   };
    //   task?: Record<string, number>;
    // }>("/billing/plans");

    const response = await this.axiosInstance.post<{
      inTrial?: boolean;
      billing?: {
        plan?: string;
        billingCycle?: string;
        subscriptionEnd?: string;
        trialEnd?: string;
        status?: string;
      };
      task?: Record<string, number>;
    }>("/user/billing/plans", {
      token: this.config.token,
      domain: this.config.domain
    });
    console.log("billing", response);
    const result = response.data;
    const date =
      result.inTrial === false
        ? result?.billing?.subscriptionEnd
        : result?.billing?.trialEnd;

    return {
      plan: result?.billing?.plan || "-",
      cycle: result?.billing?.billingCycle || "-",
      usage: result.task || {},
      renewalDate: this.formatDate(date),
      inTrial: result.inTrial || false,
      status: result?.billing?.status || "-",
    };
  }

  private formatDate(isoString?: string): string {
    if (!isoString) return "-";
    const date = new Date(isoString);
    const day = date.getDate();
    const month = date.toLocaleString("default", { month: "long" });
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  }

  handleError(context: string, error: unknown): never {
    const axiosError = error as AxiosError<{ message?: string }>;
    const errorMessage =
      axiosError.response?.data?.message ||
      axiosError.message ||
      "Unknown error";

    console.error(`${context} error:`, errorMessage);
    throw new Error(errorMessage);
  }
}

export function createClient(config: KonnectifyClientConfig): KonnectifyClient {
  return new KonnectifyClient(config);
}
