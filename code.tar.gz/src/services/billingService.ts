import { KonnectifyClient } from "./konnectifyClient";
import { storageService } from "./storageService";
import type {
  BillingInfo,
  DashboardMetrics,
  SubscriptionInfo,
} from "../types";

export class BillingService {
  constructor(private storage = storageService) {}

  async fetchBilling(client: KonnectifyClient): Promise<BillingInfo> {
    try {
      const billing = await client.getBillingInfo();
      await this.storage.setBillingInfo(billing);

      const subscription: SubscriptionInfo = {
        plan: billing.plan,
        status: billing.status,
        renewalDate: billing.renewalDate,
        billingCycle: billing.cycle,
        inTrial: billing.inTrial,
      };
      await this.storage.setSubscriptionInfo(subscription);

      return billing;
    } catch (error) {
      client.handleError("getBillingInfo", error);
    }
  }

  async getCachedBilling(): Promise<BillingInfo | null> {
    return this.storage.getBillingInfo();
  }

  async getSubscription(): Promise<SubscriptionInfo | null> {
    return this.storage.getSubscriptionInfo();
  }

  buildDashboardMetrics(
    billing: BillingInfo | null,
    connectionCount: number,
    workflows: { enabled: boolean }[],
    eventLogs: { status: string; timestamp: string }[],
  ): DashboardMetrics {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const executionsToday = eventLogs.filter((log) => {
      const logDate = new Date(log.timestamp);
      logDate.setHours(0, 0, 0, 0);
      return logDate.getTime() === today.getTime();
    }).length;

    const failedExecutions = eventLogs.filter(
      (log) => log.status === "FAILED",
    ).length;

    const activeWorkflows = workflows.filter((w) => w.enabled).length;

    let tenantStatus: DashboardMetrics["tenantStatus"] = "unknown";
    if (billing) {
      if (billing.inTrial) tenantStatus = "trial";
      else if (billing.status === "active") tenantStatus = "active";
      else tenantStatus = "inactive";
    }

    const metrics: DashboardMetrics = {
      tenantStatus,
      plan: billing?.plan ?? "-",
      connectionCount,
      activeWorkflows,
      totalWorkflows: workflows.length,
      executionsToday,
      failedExecutions,
      lastUpdated: new Date().toISOString(),
    };

    void this.storage.setDashboardMetrics(metrics);
    return metrics;
  }

  async getCachedMetrics(): Promise<DashboardMetrics | null> {
    return this.storage.getDashboardMetrics();
  }
}

export const billingService = new BillingService();
