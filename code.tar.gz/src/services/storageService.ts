// import mondaySdk from "monday-sdk-js";
// // import { SecureStorage } from '@mondaycom/apps-sdk';
// import type {
//   AuthState,
//   BillingInfo,
//   Connection,
//   DashboardMetrics,
//   EventLog,
//   SetupProgress,
//   SubscriptionInfo,
//   Tenant,
//   Workflow,
//   WorkflowTemplate,
// } from "../types";

// const monday = mondaySdk();
// // const secureStorage = new SecureStorage();

// const KEYS = {
//   tenant: "konnectify_tenant",
//   auth: "konnectify_auth",
//   bootstrapToken: "konnectify_bootstrap_token",
//   sessionPassword: "konnectify_session_pw",
//   workflows: "konnectify_workflows",
//   connections: "konnectify_connections",
//   eventLogs: "konnectify_event_logs",
//   billing: "konnectify_billing",
//   subscription: "konnectify_subscription",
//   templates: "konnectify_templates",
//   metrics: "konnectify_metrics",
//   setupProgress: "konnectify_setup_progress",
// } as const;

// // ─── Primitives ────────────────────────────────────────────────────────────
// // localStorage is primary (reliable across reloads inside monday.com iframes).
// // monday.storage is written in the background as a best-effort secondary.

// async function get<T>(key: string): Promise<T | null> {
//   // 1. Always try localStorage first — it's always available and survives reloads.
//   try {
//     const raw = localStorage.getItem(key);
//     if (raw) return JSON.parse(raw) as T;
//   } catch {
//     // ignore
//   }

//   // 2. Fall back to monday.storage in case localStorage was cleared.
//   try {
//     const res = await monday.storage.instance.getItem(key);
//     // const res = await secureStorage.get(key);
//     const raw = (res as { data?: { value?: string | null } })?.data?.value;
//     if (raw) {
//       // Restore into localStorage so future reads are fast.
//       try {
//         localStorage.setItem(key, raw);
//       } catch {}
//       return JSON.parse(raw) as T;
//     }
//   } catch {
//     // ignore — not inside a monday.com context
//   }

//   return null;
// }

// async function set<T>(key: string, value: T): Promise<void> {
//   const serialized = JSON.stringify(value);

//   // 1. Write to localStorage synchronously so the next read always succeeds.
//   try {
//     localStorage.setItem(key, serialized);
//   } catch {
//     // ignore
//   }

//   // 2. Write to monday.storage in the background (non-blocking).
//   //    This must NOT be awaited — awaiting it inside a monday frame can
//   //    trigger a context refresh / iframe reload that resets app state.
//   void monday.storage.instance.setItem(key, serialized).catch(() => {
//     // ignore — not inside a monday.com context
//   });
// }

// async function del(key: string): Promise<void> {
//   try {
//     localStorage.removeItem(key);
//   } catch {}
//   void monday.storage.instance.deleteItem(key).catch(() => {});
// }

// // ─── StorageService ────────────────────────────────────────────────────────

// export class StorageService {
//   async getTenant(): Promise<Tenant | null> {
//     return get<Tenant>(KEYS.tenant);
//   }
//   async setTenant(tenant: Tenant): Promise<void> {
//     return set(KEYS.tenant, tenant);
//   }

//   async getAuth(): Promise<AuthState | null> {
//     return get<AuthState>(KEYS.auth);
//   }
//   async setAuth(auth: AuthState): Promise<void> {
//     return set(KEYS.auth, auth);
//   }

//   async getBootstrapToken(): Promise<string | null> {
//     return get<string>(KEYS.bootstrapToken);
//   }
//   async setBootstrapToken(token: string): Promise<void> {
//     return set(KEYS.bootstrapToken, token);
//   }

//   // Stored so bootstrap tokens can be refreshed after a page reload.
//   // Bootstrap tokens expire in 120 s, so we need the credential available
//   // at any time without prompting the user again.
//   async getSessionPassword(): Promise<string | null> {
//     return get<string>(KEYS.sessionPassword);
//   }
//   async setSessionPassword(password: string): Promise<void> {
//     return set(KEYS.sessionPassword, password);
//   }

//   async getWorkflows(): Promise<Workflow[]> {
//     return (await get<Workflow[]>(KEYS.workflows)) ?? [];
//   }
//   async setWorkflows(workflows: Workflow[]): Promise<void> {
//     return set(KEYS.workflows, workflows);
//   }

//   async getEventLogs(): Promise<EventLog[]> {
//     return (await get<EventLog[]>(KEYS.eventLogs)) ?? [];
//   }
//   async setEventLogs(eventLogs: EventLog[]): Promise<void> {
//     return set(KEYS.eventLogs, eventLogs);
//   }
//   async addEventLog(eventLog: EventLog): Promise<void> {
//     const logs = await this.getEventLogs();
//     logs.unshift(eventLog);
//     if (logs.length > 200) logs.length = 200;
//     return set(KEYS.eventLogs, logs);
//   }

//   async getConnections(): Promise<Connection[]> {
//     return (await get<Connection[]>(KEYS.connections)) ?? [];
//   }
//   async setConnections(connections: Connection[]): Promise<void> {
//     return set(KEYS.connections, connections);
//   }

//   async getBillingInfo(): Promise<BillingInfo | null> {
//     return get<BillingInfo>(KEYS.billing);
//   }
//   async setBillingInfo(billingInfo: BillingInfo): Promise<void> {
//     return set(KEYS.billing, billingInfo);
//   }

//   async getSubscriptionInfo(): Promise<SubscriptionInfo | null> {
//     return get<SubscriptionInfo>(KEYS.subscription);
//   }
//   async setSubscriptionInfo(subscriptionInfo: SubscriptionInfo): Promise<void> {
//     return set(KEYS.subscription, subscriptionInfo);
//   }

//   async getWorkflowTemplates(): Promise<WorkflowTemplate[]> {
//     return (await get<WorkflowTemplate[]>(KEYS.templates)) ?? [];
//   }
//   async setWorkflowTemplates(templates: WorkflowTemplate[]): Promise<void> {
//     return set(KEYS.templates, templates);
//   }

//   async getDashboardMetrics(): Promise<DashboardMetrics | null> {
//     return get<DashboardMetrics>(KEYS.metrics);
//   }
//   async setDashboardMetrics(metrics: DashboardMetrics): Promise<void> {
//     return set(KEYS.metrics, metrics);
//   }

//   async getSetupProgress(): Promise<SetupProgress> {
//     return (
//       (await get<SetupProgress>(KEYS.setupProgress)) ?? {
//         currentStep: 1,
//         completedSteps: [],
//         templatesInstalled: false,
//       }
//     );
//   }
//   async setSetupProgress(progress: SetupProgress): Promise<void> {
//     return set(KEYS.setupProgress, progress);
//   }

//   /** @deprecated kept for compat */
//   async getConnectors(): Promise<Record<string, string>> {
//     return {};
//   }
//   /** @deprecated kept for compat */
//   async setConnectors(_connectors: Record<string, string>): Promise<void> {}

//   async clear(): Promise<void> {
//     Object.values(KEYS).forEach((k) => {
//       try {
//         localStorage.removeItem(k);
//       } catch {}
//       void monday.storage.instance.deleteItem(k).catch(() => {});
//     });
//   }

//   async isConfigured(): Promise<boolean> {
//     const tenant = await this.getTenant();
//     const auth = await this.getAuth();
//     return !!tenant && !!auth?.accessToken;
//   }
// }

// export const storageService = new StorageService();

// ====================================================================================================

import mondaySdk from "monday-sdk-js";
// import { SecureStorage } from '@mondaycom/apps-sdk';
import type {
  AuthState,
  BillingInfo,
  Connection,
  DashboardMetrics,
  EventLog,
  SetupProgress,
  SubscriptionInfo,
  Tenant,
  Workflow,
  WorkflowTemplate,
} from "../types";

const monday = mondaySdk();
// const secureStorage = new SecureStorage();

const KEYS = {
  tenant: "konnectify_tenant",
  auth: "konnectify_auth",
  bootstrapToken: "konnectify_bootstrap_token",
  sessionPassword: "konnectify_session_pw",
  workflows: "konnectify_workflows",
  connections: "konnectify_connections",
  eventLogs: "konnectify_event_logs",
  billing: "konnectify_billing",
  subscription: "konnectify_subscription",
  templates: "konnectify_templates",
  metrics: "konnectify_metrics",
  setupProgress: "konnectify_setup_progress",
} as const;

// ─── Primitives ────────────────────────────────────────────────────────────
// localStorage is primary (reliable across reloads inside monday.com iframes).
// monday.storage is written in the background as a best-effort secondary.

async function get<T>(key: string): Promise<T | null> {
 
  try {
    const res:any = await monday.storage.getItem(key);
    const value = res.data.value;
    console.log("get", key, res);
    if (value) return JSON.parse(value) as T;
  } catch(error) {
    console.log("Error while fetching value from the storage", error);
  }
  return null;
}

async function set<T>(key: string, value: T): Promise<void> {
  const serialized = JSON.stringify(value);
  console.log("set", key, serialized);
  try {
    await monday.storage.setItem(key, serialized);
  } catch (error) {
    console.log("Error in storing value", error);
  }

}

async function del(key: string): Promise<void> {
  try {
    await monday.storage.deleteItem(key);
  } catch(error) {
    console.log("Error occured while deleting the value from storage", error);
  }
}

// ─── StorageService ────────────────────────────────────────────────────────

export class StorageService {
  async getTenant(): Promise<Tenant | null> {
    return get<Tenant>(KEYS.tenant);
  }
  async setTenant(tenant: Tenant): Promise<void> {
    return set(KEYS.tenant, tenant);
  }

  async getAuth(): Promise<AuthState | null> {
    return get<AuthState>(KEYS.auth);
  }
  async setAuth(auth: AuthState): Promise<void> {
    return set(KEYS.auth, auth);
  }

  async getBootstrapToken(): Promise<string | null> {
    return get<string>(KEYS.bootstrapToken);
  }
  async setBootstrapToken(token: string): Promise<void> {
    return set(KEYS.bootstrapToken, token);
  }

  // Stored so bootstrap tokens can be refreshed after a page reload.
  // Bootstrap tokens expire in 120 s, so we need the credential available
  // at any time without prompting the user again.
  async getSessionPassword(): Promise<string | null> {
    return get<string>(KEYS.sessionPassword);
  }
  async setSessionPassword(password: string): Promise<void> {
    return set(KEYS.sessionPassword, password);
  }

  async getWorkflows(): Promise<Workflow[]> {
    return (await get<Workflow[]>(KEYS.workflows)) ?? [];
  }
  async setWorkflows(workflows: Workflow[]): Promise<void> {
    return set(KEYS.workflows, workflows);
  }

  async getEventLogs(): Promise<EventLog[]> {
    return (await get<EventLog[]>(KEYS.eventLogs)) ?? [];
  }
  async setEventLogs(eventLogs: EventLog[]): Promise<void> {
    return set(KEYS.eventLogs, eventLogs);
  }
  async addEventLog(eventLog: EventLog): Promise<void> {
    const logs = await this.getEventLogs();
    logs.unshift(eventLog);
    if (logs.length > 200) logs.length = 200;
    return set(KEYS.eventLogs, logs);
  }

  async getConnections(): Promise<Connection[]> {
    return (await get<Connection[]>(KEYS.connections)) ?? [];
  }
  async setConnections(connections: Connection[]): Promise<void> {
    console.log("siva storing connection in db");
    return set(KEYS.connections, connections);
  }

  async getBillingInfo(): Promise<BillingInfo | null> {
    return get<BillingInfo>(KEYS.billing);
  }
  async setBillingInfo(billingInfo: BillingInfo): Promise<void> {
    return set(KEYS.billing, billingInfo);
  }

  async getSubscriptionInfo(): Promise<SubscriptionInfo | null> {
    return get<SubscriptionInfo>(KEYS.subscription);
  }
  async setSubscriptionInfo(subscriptionInfo: SubscriptionInfo): Promise<void> {
    return set(KEYS.subscription, subscriptionInfo);
  }

  async getWorkflowTemplates(): Promise<WorkflowTemplate[]> {
    return (await get<WorkflowTemplate[]>(KEYS.templates)) ?? [];
  }
  async setWorkflowTemplates(templates: WorkflowTemplate[]): Promise<void> {
    return set(KEYS.templates, templates);
  }

  async getDashboardMetrics(): Promise<DashboardMetrics | null> {
    return get<DashboardMetrics>(KEYS.metrics);
  }
  async setDashboardMetrics(metrics: DashboardMetrics): Promise<void> {
    return set(KEYS.metrics, metrics);
  }

  async getSetupProgress(): Promise<SetupProgress> {
    return (
      (await get<SetupProgress>(KEYS.setupProgress)) ?? {
        currentStep: 1,
        completedSteps: [],
        templatesInstalled: false,
      }
    );
  }
  async setSetupProgress(progress: SetupProgress): Promise<void> {
    return set(KEYS.setupProgress, progress);
  }

  /** @deprecated kept for compat */
  async getConnectors(): Promise<Record<string, string>> {
    return {};
  }
  /** @deprecated kept for compat */
  async setConnectors(_connectors: Record<string, string>): Promise<void> {}

  async clear(): Promise<void> {
    Object.values(KEYS).forEach(async(k) => {
      // try {
      //   localStorage.removeItem(k);
      // } catch {}
      // void monday.storage.instance.deleteItem(k).catch(() => {});
      await del(k)
    });
  }

  async isConfigured(): Promise<boolean> {
    const tenant = await this.getTenant();
    const auth = await this.getAuth();
    return !!tenant && !!auth?.accessToken;
  }
}

export const storageService = new StorageService();

