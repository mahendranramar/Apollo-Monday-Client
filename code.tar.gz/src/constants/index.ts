export const ROOT_DOMAIN = ".stack5.us.konnectify.dev"; // .prestaging.us.konnectify.dev
export const API_PATH = "/ipaas/api";
export const UI_PATH = "/ipaas/ui";

export const APP_IDS = {
  monday: "mondaycrm-1.0.0",
  freshsales: "freshsales-1.0.0",
} as const;

// export const WORKFLOW_TEMPLATE_IDS = [3] as const;
export const WORKFLOW_TEMPLATE_IDS = [11] as const;

export const WORKFLOW_TEMPLATES = [
  {
    id: 133,
    name: "Contact Sync",
    description:
      "Syncs newly created or modified contacts between Monday.com and Attio.",
  },
  {
    id: 134,
    name: "Account Sync",
    description:
      "Syncs newly created or modified accounts between Monday.com and Attio.",
  },
] as const;

export const ACCOUNT_SETTINGS_SECTIONS = [
  { id: "connections", label: "Connections" },
] as const;

export const BOARD_VIEW_SECTIONS = [
  { id: "overview", label: "Overview" },
  { id: "workflows", label: "Workflows" },
  { id: "logs", label: "Event Logs" },
] as const;

export type AccountSettingsSection =
  (typeof ACCOUNT_SETTINGS_SECTIONS)[number]["id"];
export type BoardViewSection = (typeof BOARD_VIEW_SECTIONS)[number]["id"];
