import React, { useState } from "react";
import { Loader, Tab, TabList, TabPanel, TabPanels } from "@vibe/core";
import { useKonnectify } from "../../hooks";
import { EventLogsPanel } from "./EventLogsPanel";
import { WorkflowTable } from "./WorkflowTable";
import styles from "./BoardView.module.css";

export const BoardView: React.FC = () => {
  const { loading } = useKonnectify();
  const [activeTab, setActiveTab] = useState(0);

  if (loading) {
    return (
      <div className={styles.loaderWrapper}>
        <Loader size="medium" />
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Konnectify</h1>
          <p className={styles.subtitle}>Monitor and manage your integration workflows</p>
        </div>
      </div>

      <div className={styles.tabsWrapper}>
        <TabList activeTabId={activeTab} onTabChange={setActiveTab}>
          <Tab value={0}>Konnectors</Tab>
          <Tab value={1}>Event Logs</Tab>
        </TabList>

        <TabPanels activeTabId={activeTab}>
          <TabPanel index={0}>
            <div className={styles.panel}>
              <WorkflowTable />
            </div>
          </TabPanel>
          <TabPanel index={1}>
            <div className={styles.panel}>
              <EventLogsPanel />
            </div>
          </TabPanel>
        </TabPanels>
      </div>
    </div>
  );
};
