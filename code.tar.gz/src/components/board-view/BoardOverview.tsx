import React, { useEffect } from "react";
import { AttentionBox, Loader, Text } from "@vibe/core";
import { useKonnectify } from "../../hooks";
import { StatusLabel } from "../common/StatusLabel";
import styles from "./BoardOverview.module.css";

export const BoardOverview: React.FC = () => {
  const {
    metrics,
    workflows,
    connections,
    refreshDashboard,
    isConfigured,
    loading,
  } = useKonnectify();

  useEffect(() => {
    if (isConfigured) {
      void refreshDashboard();
    }
  }, [isConfigured, refreshDashboard]);

  if (loading && !metrics) {
    return (
      <div className={styles.loader}>
        <Loader size="medium" />
      </div>
    );
  }

  if (!isConfigured) {
    return (
      <AttentionBox
        title="Not configured"
        text="Configure your Konnectify account in Account Settings first."
        type="warning"
      />
    );
  }

  const failureRate =
    metrics && metrics.executionsToday > 0
      ? Math.round((metrics.failedExecutions / metrics.executionsToday) * 100)
      : 0;

  return (
    <div className={styles.container}>
      <div className={styles.grid}>
        <StatCard label="Active Workflows" value={metrics?.activeWorkflows ?? 0} />
        <StatCard label="Executions Today" value={metrics?.executionsToday ?? 0} />
        <StatCard
          label="Failures"
          value={metrics?.failedExecutions ?? 0}
          badge={failureRate > 0 ? `${failureRate}%` : undefined}
          warn={Boolean(metrics?.failedExecutions)}
        />
        <StatCard label="Connections" value={connections.length} />
        <StatCard label="Total Workflows" value={workflows.length} />
      </div>
    </div>
  );
};

function StatCard({
  label,
  value,
  badge,
  warn,
}: {
  label: string;
  value: number;
  badge?: string;
  warn?: boolean;
}) {
  return (
    <div className={`${styles.card} ${warn ? styles.warn : ""}`}>
      <Text type="text2" color="secondary">
        {label}
      </Text>
      <div className={styles.valueRow}>
        <Text type="text1" weight="bold" className={styles.value}>
          {value}
        </Text>
        {badge && <StatusLabel text={badge} tone="negative" />}
      </div>
    </div>
  );
}
