import React from "react";
import { Button } from "@vibe/core";
import styles from "./SideNav.module.css";

export interface NavItem {
  id: string;
  label: string;
}

interface SideNavProps {
  items: NavItem[];
  activeId: string;
  onChange: (id: string) => void;
}

export const SideNav: React.FC<SideNavProps> = ({ items, activeId, onChange }) => {
  return (
    <nav className={styles.nav} aria-label="Section navigation">
      {items.map((item) => (
        <Button
          key={item.id}
          kind={activeId === item.id ? "primary" : "tertiary"}
          size="medium"
          onClick={() => onChange(item.id)}
          className={styles.navButton}
          aria-current={activeId === item.id ? "page" : undefined}
        >
          {item.label}
        </Button>
      ))}
    </nav>
  );
};
