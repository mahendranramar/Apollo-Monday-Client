import React from "react";
import { Label } from "@vibe/core";

type StatusTone = "positive" | "negative" | "warning" | "neutral" | "primary";

const colorMap: Record<StatusTone, "positive" | "negative" | "primary" | "dark"> = {
  positive: "positive",
  negative: "negative",
  warning: "primary",
  neutral: "dark",
  primary: "primary",
};

interface StatusLabelProps {
  text: string;
  tone?: StatusTone;
}

export const StatusLabel: React.FC<StatusLabelProps> = ({
  text,
  tone = "neutral",
}) => {
  return <Label text={text} color={colorMap[tone]} kind="fill" size="small" />;
};
