import React, { useEffect } from "react";
import {
  AttentionBox,
  Avatar,
  Loader,
  Text,
} from "@vibe/core";
import { useKonnectify } from "../../hooks";
import { StatusLabel } from "../common/StatusLabel";
import styles from "./OverviewDashboard.module.css";

export const OverviewDashboard: React.FC = () => {
  const { metrics, tenant, auth, refreshDashboard, loading, isConfigured } =
    useKonnectify();

  useEffect(() => {
    if (isConfigured) {
      void refreshDashboard();
    }
  }, [isConfigured, refreshDashboard]);

  if (loading && !metrics) {
    return (
      <div className={styles.loader}>
        <Loader size="medium" />
      </div>
    );
  }

  if (!isConfigured) {
    return (
      <AttentionBox
        title="Setup required"
        text="Complete the setup wizard in Settings to activate your Konnectify tenant."
        type="warning"
      />
    );
  }

  const statusColor =
    metrics?.tenantStatus === "active"
      ? "positive"
      : metrics?.tenantStatus === "trial"
        ? "warning"
        : "negative";

  return (
    <div className={styles.container}>
      <div className={styles.tenantBanner}>
        <Avatar
          type="text"
          text={tenant?.domain?.substring(0, 2).toUpperCase() ?? "KN"}
          size="large"
        />
        <div>
          <Text type="text1" weight="bold">
            {tenant?.domain}.konnectifyapp.co
          </Text>
          <Text type="text2" color="secondary">
            {auth?.email}
          </Text>
        </div>
        <StatusLabel text={metrics?.tenantStatus ?? "unknown"} tone={statusColor} />
      </div>

      <div className={styles.grid}>
        <MetricCard
          label="Connections"
          value={String(metrics?.connectionCount ?? 0)}
        />
        <MetricCard
          label="Active Workflows"
          value={String(metrics?.activeWorkflows ?? 0)}
        />
        <MetricCard
          label="Executions Today"
          value={String(metrics?.executionsToday ?? 0)}
        />
        <MetricCard
          label="Failed Executions"
          value={String(metrics?.failedExecutions ?? 0)}
          highlight={Boolean(metrics?.failedExecutions)}
        />
      </div>
    </div>
  );
};

function MetricCard({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className={`${styles.card} ${highlight ? styles.highlight : ""}`}>
      <Text type="text2" color="secondary">
        {label}
      </Text>
      <Text type="text1" weight="bold" className={styles.value}>
        {value}
      </Text>
    </div>
  );
}
