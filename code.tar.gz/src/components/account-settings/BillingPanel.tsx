import React, { useEffect, useState } from "react";
import {
  AttentionBox,
  Button,
  Loader,
  Text,
} from "@vibe/core";
import { useKonnectify } from "../../hooks";
import { EmptyPlaceholder } from "../common/EmptyPlaceholder";
import { StatusLabel } from "../common/StatusLabel";
import styles from "./BillingPanel.module.css";

export const BillingPanel: React.FC = () => {
  const {
    billing,
    connections,
    workflows,
    tenant,
    refreshBilling,
    isConfigured,
    loading,
  } = useKonnectify();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (isConfigured) {
      void refreshBilling();
    }
  }, [isConfigured, refreshBilling]);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await refreshBilling();
    } finally {
      setRefreshing(false);
    }
  };

  const openBillingPortal = () => {
    if (!tenant) return;
    window.open(`https://${tenant.domain}.konnectifyapp.co/ipaas/ui/billing`, "_blank");
  };

  if (!isConfigured) {
    return (
      <EmptyPlaceholder
        title="Not configured"
        description="Sign in to view billing information."
      />
    );
  }

  if (loading && !billing) {
    return (
      <div className={styles.loader}>
        <Loader size="medium" />
      </div>
    );
  }

  const usageConsumed = billing?.usage?.consumed ?? 0;
  const usageTotal = billing?.usage?.total ?? 0;
  const usagePercent =
    usageTotal > 0 ? Math.round((usageConsumed / usageTotal) * 100) : 0;

  return (
    <div className={styles.container}>
      <div className={styles.toolbar}>
        <Text type="text2" color="secondary">
          Subscription and usage for your Konnectify tenant.
        </Text>
        <Button kind="secondary" onClick={() => void handleRefresh()} loading={refreshing}>
          Refresh
        </Button>
      </div>

      {billing?.inTrial && (
        <AttentionBox
          title="Trial active"
          text={`Your trial ends on ${billing.renewalDate}. Upgrade to continue using Konnectify.`}
          type="warning"
        />
      )}

      <div className={styles.grid}>
        <div className={styles.card}>
          <Text type="text2" color="secondary">
            Subscription Plan
          </Text>
          <div className={styles.planRow}>
            <Text type="text1" weight="bold">
              {billing?.plan ?? "-"}
            </Text>
            <StatusLabel
              text={billing?.status ?? "unknown"}
              tone={billing?.status === "active" ? "positive" : "neutral"}
            />
          </div>
          <Text type="text2" color="secondary">
            Cycle: {billing?.cycle ?? "-"}
          </Text>
          <Text type="text2" color="secondary">
            Renewal: {billing?.renewalDate ?? "-"}
          </Text>
        </div>

        <div className={styles.card}>
          <Text type="text2" color="secondary">
            Usage
          </Text>
          <Text type="text1" weight="bold" className={styles.usageValue}>
            {usageConsumed} / {usageTotal} tasks
          </Text>
          <div className={styles.progressBar}>
            <div
              className={styles.progressFill}
              style={{ width: `${Math.min(usagePercent, 100)}%` }}
            />
          </div>
          <Text type="text3" color="secondary">
            {usagePercent}% consumed
          </Text>
        </div>

        <div className={styles.card}>
          <Text type="text2" color="secondary">
            Resource Counts
          </Text>
          <div className={styles.statRow}>
            <Text type="text2">Workflows</Text>
            <Text type="text1" weight="bold">
              {workflows.length}
            </Text>
          </div>
          <div className={styles.statRow}>
            <Text type="text2">Connections</Text>
            <Text type="text1" weight="bold">
              {connections.length}
            </Text>
          </div>
        </div>
      </div>

      <Button kind="primary" onClick={openBillingPortal}>
        Manage Konnectify Plan
      </Button>
    </div>
  );
};
