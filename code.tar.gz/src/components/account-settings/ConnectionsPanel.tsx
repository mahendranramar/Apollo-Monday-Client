import React, { useCallback, useEffect, useState } from "react";
import {
  Button,
  Loader,
  Modal,
  ModalBasicLayout,
  ModalContent,
  ModalHeader,
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHeaderCell,
  TableRow,
  Text,
  TextField,
} from "@vibe/core";
import { APP_IDS } from "../../constants";
import { useKonnectify } from "../../hooks";
import { connectionService } from "../../services/connectionService";
import { iframeService } from "../../services/iframeService";
import { EmptyPlaceholder } from "../common/EmptyPlaceholder";
import { KonnectifyIframeModal } from "../common/KonnectifyIframeModal";
import { StatusLabel } from "../common/StatusLabel";
import { useToast } from "../common/useToast";
import type { Connection } from "../../types";
import styles from "./ConnectionsPanel.module.css";

type ConnectionModalMode = "edit" | "reconnect" | "create" | null;

export const ConnectionsPanel: React.FC = () => {
  const {
    client,
    tenant,
    connections,
    refreshConnections,
    isConfigured,
    ensureToken,
    addEventLog,
  } = useKonnectify();
  const { showToast, toastElement } = useToast();
  const [loading, setLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [modalMode, setModalMode] = useState<ConnectionModalMode>(null);
  const [selectedConnection, setSelectedConnection] = useState<Connection | null>(null);
  const [connectionName, setConnectionName] = useState("");
  const [selectedAppId, setSelectedAppId] = useState<string>(APP_IDS.monday);
  const [iframeUrl, setIframeUrl] = useState<string | null>(null);
  const [iframeTitle, setIframeTitle] = useState("");
  const [iframeOpen, setIframeOpen] = useState(false);

  useEffect(() => {
    if (isConfigured) {
      void loadConnections();
    }
  }, [isConfigured]);

  const loadConnections = async () => {
    setLoading(true);
    try {
      await refreshConnections();
    } finally {
      setLoading(false);
    }
  };

  // Creation is handled by dedicated Connect buttons (Monday / D365)

  const openEditDialog = (connection: Connection) => {
    setSelectedConnection(connection);
    setConnectionName(connection.name);
    setSelectedAppId(connection.appId);
    setModalMode("edit");
    setDialogOpen(true);
  };

  const handleDelete = async (connection: Connection) => {
    if (!client || !confirm(`Delete connection "${connection.name}"?`)) return;
    try {
      await connectionService.delete(client, connection.id);
      showToast("Connection deleted", "positive");
      await addEventLog({
        id: `log_${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: "CONNECTION",
        status: "SUCCESS",
        message: `Deleted connection ${connection.name}`,
        workflowId: "system",
      });
      await refreshConnections();
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Delete failed", "negative");
    }
  };

  const handleOAuthReconnect = async (connection: Connection) => {
    if (!client || !tenant) return;
    try {
      const { authUrl } = await connectionService.getOAuthUrl(
        client,
        connection.appId,
        connection.name,
      );
      window.open(authUrl, "_blank", "noopener,noreferrer");
      showToast("Complete OAuth in the new window, then refresh.", "normal");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "OAuth failed", "negative");
    }
  };

  const handleDialogSubmit = async () => {
    if (!client || !connectionName.trim() || modalMode !== "edit" || !selectedConnection) return;

    try {
      await connectionService.edit(
        client,
        selectedConnection.id,
        selectedAppId,
        connectionName,
        selectedConnection.data,
      );
      showToast("Connection updated", "positive");
      setDialogOpen(false);
      await refreshConnections();
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Operation failed", "negative");
    }
  };

  const handleConnectMonday = async () => {
    if (!client) return;
    setLoading(true);
    try {
      await connectionService.create(client, APP_IDS.monday, "Monday.com Connection");
      showToast("Monday.com connected", "positive");
      await refreshConnections();
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Connection failed", "negative");
    } finally {
      setLoading(false);
    }
  };

  const handleConnectAttio = async () => {
    if (!client) return;
    setLoading(true);
    try {
      const { authUrl } = await connectionService.getOAuthUrl(client, APP_IDS.freshsales, "Freshsales Connection");
      window.open(authUrl, "_blank", "noopener,noreferrer");
      showToast("Complete OAuth in the new window", "normal");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "OAuth failed", "negative");
    } finally {
      setLoading(false);
    }
  };

  const openConnectionIframe = useCallback(
    async (mode: "create" | "edit") => {
      if (!tenant) return;
      setLoading(true);
      try {
        const token = await ensureToken();
        const url = iframeService.buildBootstrapUrl(
          tenant.domain,
          mode === "create" ? "/connections/new" : `/connections/${selectedConnection?.id}`,
          token,
        );
        setIframeTitle(mode === "create" ? "Create Connection" : "Edit Connection");
        setIframeUrl(url);
        setIframeOpen(true);
      } catch (err) {
        showToast(err instanceof Error ? err.message : "Failed to open editor", "negative");
      } finally {
        setLoading(false);
      }
    },
    [tenant, ensureToken, selectedConnection, showToast],
  );

  if (!isConfigured) {
    return (
      <EmptyPlaceholder
        title="Not configured"
        description="Sign in to manage connections."
      />
    );
  }

  return (
    <div className={styles.container}>
      {toastElement}

      <div className={styles.toolbar}>
        <Text type="text2" color="secondary">
          Manage integrations between Monday.com and Attio.
        </Text>
        <div className={styles.toolbarActions}>
          <Button kind="secondary" onClick={() => void loadConnections()} loading={loading}>
            Refresh
          </Button>
          <Button kind="primary" onClick={() => void handleConnectMonday()} loading={loading}>
            Connect Monday
          </Button>
          <Button kind="primary" onClick={() => void handleConnectAttio()} loading={loading}>
            Connect Freshsales
          </Button>
        </div>
      </div>

      {loading && connections.length === 0 ? (
        <div className={styles.loader}>
          <Loader size="medium" />
        </div>
      ) : connections.length === 0 ? (
        <EmptyPlaceholder
          title="No connections"
          description="Connect to Monday.com and Attio to start syncing."
          action={
            <div className={styles.emptyActions}>
              <Button kind="primary" onClick={() => void handleConnectMonday()}>
                Connect Monday
              </Button>
              <Button kind="secondary" onClick={() => void handleConnectAttio()}>
                Connect Freshsales
              </Button>
            </div>
          }
        />
      ) : (
        <Table
          columns={[
            { id: "name", title: "Connection Name", width: 240 },
            { id: "status", title: "Status", width: 120 },
            { id: "user", title: "Connected User", width: 200 },
            { id: "updated", title: "Last Updated", width: 160 },
            { id: "actions", title: "Actions", width: 280 },
          ]}
          errorState={<EmptyPlaceholder title="Error" description="Failed to load connections." />}
          emptyState={<EmptyPlaceholder title="No connections" description="No connections found." />}
        >
          <TableHeader>
            <TableHeaderCell title="Connection Name" />
            <TableHeaderCell title="Status" />
            <TableHeaderCell title="Connected User" />
            <TableHeaderCell title="Last Updated" />
            <TableHeaderCell title="Actions" />
          </TableHeader>
          <TableBody>
            {connections.map((connection) => (
              <TableRow key={connection.id}>
                <TableCell>{connection.name}</TableCell>
                <TableCell>
                  <StatusLabel
                    text={connection.status ?? "unknown"}
                    tone={connection.status === "active" ? "positive" : "neutral"}
                  />
                </TableCell>
                <TableCell>{connection.connectedUser ?? "-"}</TableCell>
                <TableCell>
                  {connection.updatedAt
                    ? new Date(connection.updatedAt).toLocaleString()
                    : "-"}
                </TableCell>
                <TableCell>
                  <div className={styles.rowActions}>
                    <Button
                      kind="tertiary"
                      size="small"
                      onClick={() => openEditDialog(connection)}
                    >
                      Edit
                    </Button>
                    <Button
                      kind="tertiary"
                      size="small"
                      onClick={() => void handleOAuthReconnect(connection)}
                    >
                      Reconnect
                    </Button>
                    <Button
                      kind="tertiary"
                      size="small"
                      color="negative"
                      onClick={() => void handleDelete(connection)}
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      <Modal
        id="connection-form-modal"
        show={dialogOpen}
        onClose={() => setDialogOpen(false)}
        size="medium"
      >
        <ModalBasicLayout>
          <ModalHeader
            title={modalMode === "create" ? "Create Connection" : "Edit Connection"}
          />
          <ModalContent>
          <div className={styles.dialogForm}>
            <TextField
              title="Connection Name"
              placeholder="My Monday Connection"
              value={connectionName}
              onChange={setConnectionName}
            />
            <div className={styles.appSelect}>
              <Text type="text2" weight="normal">
                Application
              </Text>
              <div className={styles.appButtons}>
                <Button
                  kind={selectedAppId === APP_IDS.monday ? "primary" : "secondary"}
                  onClick={() => setSelectedAppId(APP_IDS.monday)}
                >
                  Monday.com
                </Button>
                <Button
                  kind={selectedAppId === APP_IDS.freshsales ? "primary" : "secondary"}
                  onClick={() => setSelectedAppId(APP_IDS.freshsales)}
                >
                  Attio
                </Button>
              </div>
            </div>
            <div className={styles.dialogActions}>
              <Button kind="secondary" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button kind="primary" onClick={() => void handleDialogSubmit()}>
                Save
              </Button>
              <Button kind="tertiary" onClick={() => void openConnectionIframe("edit")}>
                Open in Editor
              </Button>
            </div>
          </div>
          </ModalContent>
        </ModalBasicLayout>
      </Modal>

      <KonnectifyIframeModal
        id="connection-iframe-modal"
        show={iframeOpen}
        title={iframeTitle}
        url={iframeUrl}
        loading={loading}
        onClose={() => {
          setIframeOpen(false);
          setIframeUrl(null);
          void refreshConnections();
        }}
      />
    </div>
  );
};
