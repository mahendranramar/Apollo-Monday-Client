import React, { useEffect, useState } from "react";
import { Button, Loader, Text } from "@vibe/core";
import { useKonnectify } from "../../hooks";
import { workflowService } from "../../services/workflowService";
import { iframeService } from "../../services/iframeService";
import { EmptyPlaceholder } from "../common/EmptyPlaceholder";
import { KonnectifyIframeModal } from "../common/KonnectifyIframeModal";
import { StatusLabel } from "../common/StatusLabel";
import { useToast } from "../common/useToast";
import styles from "./WorkflowTemplatesPanel.module.css";

export const WorkflowTemplatesPanel: React.FC = () => {
  const {
    client,
    tenant,
    templates,
    refreshTemplates,
    isConfigured,
    ensureToken,
    addEventLog,
    updateSetupProgress,
  } = useKonnectify();
  const { showToast, toastElement } = useToast();
  const [loading, setLoading] = useState(false);
  const [iframeOpen, setIframeOpen] = useState(false);
  const [iframeUrl, setIframeUrl] = useState<string | null>(null);
  const [iframeTitle, setIframeTitle] = useState("");

  useEffect(() => {
    if (isConfigured) {
      void refreshTemplates();
    }
  }, [isConfigured, refreshTemplates]);

  const handleInstall = async (templateId: number, name: string, reinstall = false) => {
    if (!client) return;
    setLoading(true);
    try {
      if (reinstall) {
        await workflowService.reinstallTemplate(client, templateId);
      } else {
        await client.installKonnectorFromTemplate(templateId);
      }
      showToast(`${name} ${reinstall ? "reinstalled" : "installed"} successfully`, "positive");
      await addEventLog({
        id: `log_${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: "SYNC",
        status: "SUCCESS",
        message: `${reinstall ? "Reinstalled" : "Installed"} template ${name}`,
        workflowId: String(templateId),
      });
      await updateSetupProgress({ templatesInstalled: true });
      await refreshTemplates();
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Install failed", "negative");
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = async (templateId: number, name: string, konnectorId?: string) => {
    if (!tenant) return;
    setLoading(true);
    try {
      const token = await ensureToken();
      const url = konnectorId
        ? iframeService.buildDestinationUrl(tenant.domain, {
            type: "preview",
            workflowId: konnectorId,
          }, token)
        : iframeService.buildBootstrapUrl(
            tenant.domain,
            `/templates/${templateId}`,
            token,
          );
      setIframeTitle(`Preview: ${name}`);
      setIframeUrl(url);
      setIframeOpen(true);
    } catch (err) {
      showToast(err instanceof Error ? err.message : "Preview failed", "negative");
    } finally {
      setLoading(false);
    }
  };

  if (!isConfigured) {
    return (
      <EmptyPlaceholder
        title="Not configured"
        description="Complete setup to install workflow templates."
      />
    );
  }

  return (
    <div className={styles.container}>
      {toastElement}

      {loading && templates.length === 0 ? (
        <div className={styles.loader}>
          <Loader size="medium" />
        </div>
      ) : (
        <div className={styles.grid}>
          {templates.map((template) => (
            <div key={template.id} className={styles.card}>
              <div className={styles.cardHeader}>
                <Text type="text1" weight="bold">
                  {template.name}
                </Text>
                <StatusLabel
                  text={template.installed ? "Installed" : "Available"}
                  tone={template.installed ? "positive" : "neutral"}
                />
              </div>
              <Text type="text2" color="secondary">
                {template.description}
              </Text>
              <Text type="text3" color="secondary">
                Template ID: {template.id}
              </Text>
              <div className={styles.actions}>
                <Button
                  kind="secondary"
                  size="small"
                  onClick={() => void handlePreview(template.id, template.name, template.konnectorId)}
                >
                  Preview
                </Button>
                {!template.installed ? (
                  <Button
                    kind="primary"
                    size="small"
                    loading={loading}
                    onClick={() => void handleInstall(template.id, template.name)}
                  >
                    Install
                  </Button>
                ) : (
                  <Button
                    kind="tertiary"
                    size="small"
                    loading={loading}
                    onClick={() => void handleInstall(template.id, template.name, true)}
                  >
                    Reinstall
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <KonnectifyIframeModal
        id="template-preview-modal"
        show={iframeOpen}
        title={iframeTitle}
        url={iframeUrl}
        loading={loading}
        onClose={() => {
          setIframeOpen(false);
          setIframeUrl(null);
        }}
      />
    </div>
  );
};
