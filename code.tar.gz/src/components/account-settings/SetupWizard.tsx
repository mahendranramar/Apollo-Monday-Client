import React, { useEffect, useState } from "react";
import { Button, Loader, Text } from "@vibe/core";
import { Check, Email, Globe, Locked, Person, Warning } from "@vibe/icons";
import { useKonnectify } from "../../hooks";
import { APP_IDS } from "../../constants";
import { connectionService } from "../../services/connectionService";
import styles from "./SetupWizard.module.css";
import axios from 'axios';
import mondaySdk from "monday-sdk-js";
const monday = mondaySdk();


// ─── Step types ──────────────────────────────────────────────────────────────

type Step = "auth" | "monday" | "freshsales" | "templates";

const STEPS: Array<{ id: Step; label: string }> = [
  { id: "auth", label: "Sign In / Up" },
  { id: "monday", label: "Connect Monday" },
  { id: "freshsales", label: "Connect Freshsales" },
  { id: "templates", label: "Install Templates" },
];

// ─── SetupWizard ─────────────────────────────────────────────────────────────

const STEP_NUMBER_TO_ID: Record<number, Step> = {
  1: "auth",
  2: "monday",
  3: "freshsales",
  4: "templates",
};

export const SetupWizard: React.FC = () => {
  const {
    client,
    login,
    registerUser,
    isConfigured,
    loading: contextLoading,
    updateSetupProgress,
    refreshConnections,
    setupProgress
  } = useKonnectify();
  // client is used in step handlers (handleMondayConnect, handleFreshsalesConnect)

  const [currentStep, setCurrentStep] = useState<Step>("auth");
  const [completed, setCompleted] = useState<Set<Step>>(new Set<Step>());
  const [initialized, setInitialized] = useState(false);
  const [errors, setErrors] = useState<Record<Step, string>>({
    auth: "",
    monday: "",
    freshsales: "",
    templates: "",
  });
  const [submitting, setSubmitting] = useState(false);

  // Restore wizard position from persisted setupProgress once context has loaded.
  useEffect(() => {
    if (contextLoading || initialized) return;

    const restoredCompleted = new Set<Step>(
      setupProgress.completedSteps
        .map((n) => STEP_NUMBER_TO_ID[n])
        .filter(Boolean) as Step[],
    );

    // If the user is already authenticated (session survived reload), mark auth done.
    if (isConfigured && !restoredCompleted.has("auth")) {
      restoredCompleted.add("auth");
    }

    setCompleted(restoredCompleted);

    // Jump to the furthest incomplete step.
    const orderedSteps: Step[] = ["auth", "monday", "freshsales", "templates"];
    const firstIncomplete = orderedSteps.find((s) => !restoredCompleted.has(s));
    setCurrentStep(firstIncomplete ?? "templates");

    setInitialized(true);
  }, [contextLoading, initialized, setupProgress, isConfigured]);

  const markError = (step: Step, msg: string) =>
    setErrors((prev) => ({ ...prev, [step]: msg }));
  const clearError = (step: Step) =>
    setErrors((prev) => ({ ...prev, [step]: "" }));

  const advance = (from: Step) => {
    setCompleted((prev) => new Set([...prev, from]));
    const idx = STEPS.findIndex((s) => s.id === from);
    if (idx < STEPS.length - 1) setCurrentStep(STEPS[idx + 1].id);
  };

  // ── Step 1: Auth ────────────────────────────────────────────────────────────
  const handleAuth = async (
    domain: string,
    email: string,
    password: string,
    isLogin: boolean,
    name?: string,
    website?: string,
  ) => {
    clearError("auth");
    setSubmitting(true);
    try {
      if (isLogin) {
        await login(domain, email, password);
      } else {
        await registerUser(domain, email, password, name ?? "", website);
      }
      advance("auth");
    } catch (err) {
      markError("auth", err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Step 2: Monday ──────────────────────────────────────────────────────────
  const handleMondayConnect = async (apiToken: string) => {
    console.log("siva-handle monday fn called", apiToken)
    clearError("monday");
    if (!apiToken.trim()) {
      markError("monday", "API token is required");
      return;
    }
    setSubmitting(true);
    try {
      if (!client) throw new Error("Client not initialised");
      await connectionService.create(client, APP_IDS.monday, "Monday Connection", {
        api_key: apiToken,
      });
      await refreshConnections();
      const newCompleted = Array.from(new Set([...(setupProgress.completedSteps ?? []), 2]));
      await updateSetupProgress({ currentStep: 3, completedSteps: newCompleted });
      advance("monday");
    } catch (err) {
      markError("monday", err instanceof Error ? err.message : "Failed to connect Monday");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Step 3: Freshsales ──────────────────────────────────────────────────────
  const handleFreshsalesConnect = async (domain: string, apiKey: string) => {
    clearError("freshsales");
    setSubmitting(true);
    try {
      if (!client) throw new Error("Client not initialised");
      await connectionService.create(client, APP_IDS.freshsales, "Freshsales Connection", {
        domain,
        api_key: apiKey,
      });
      await refreshConnections();
      const newCompleted = Array.from(new Set([...(setupProgress.completedSteps ?? []), 3]));
      await updateSetupProgress({ currentStep: 4, completedSteps: newCompleted });
      advance("freshsales");
    } catch (err) {
      markError("freshsales", err instanceof Error ? err.message : "Failed to connect Freshsales");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Step 4: Templates ───────────────────────────────────────────────────────
  const handleInstallTemplates = async () => {
    clearError("templates");
    setSubmitting(true);
    try {
      if (!client) throw new Error("Client not initialised");
      await Promise.all([
        client.installKonnectorFromTemplate(3),
        // client.installKonnectorFromTemplate(134),
      ]);
      const newCompleted = Array.from(new Set([...(setupProgress.completedSteps ?? []), 4]));
      await updateSetupProgress({ currentStep: 4, completedSteps: newCompleted, templatesInstalled: true });
      advance("templates");
    } catch (err) {
      markError(
        "templates",
        err instanceof Error ? err.message : "Failed to install templates",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const currentIndex = STEPS.findIndex((s) => s.id === currentStep);
  const isComplete = completed.has("templates") || setupProgress.templatesInstalled;

  if (contextLoading || !initialized) {
    return (
      <div className={styles.stepContent} style={{ display: "flex", justifyContent: "center", padding: 48 }}>
        <Loader size="medium" />
      </div>
    );
  }

  if (isComplete) {
    return (
      <div className={styles.stepContent}>
        <CompleteStep />
      </div>
    );
  }

  return (
    <div className={styles.wizardContainer}>
      {/* ── Step indicator ───────────────────────────────────────────────── */}
      <div className={styles.stepIndicator}>
        <div className={styles.stepsWrapper}>
          {STEPS.map((step, index) => (
            <React.Fragment key={step.id}>
              <button
                className={[
                  styles.stepButton,
                  currentStep === step.id ? styles.stepButtonActive : "",
                  completed.has(step.id) ? styles.stepButtonCompleted : "",
                ]
                  .filter(Boolean)
                  .join(" ")}
                onClick={() => {
                  if (index < currentIndex || completed.has(step.id)) {
                    setCurrentStep(step.id);
                  }
                }}
                disabled={index > currentIndex && !completed.has(step.id)}
              >
                <div className={styles.stepCircle}>
                  {completed.has(step.id) ? (
                    <Check size={16} />
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>
                <span className={styles.stepLabel}>{step.label}</span>
              </button>
              {index < STEPS.length - 1 && (
                <div
                  className={[
                    styles.stepDivider,
                    index < currentIndex ? styles.stepDividerCompleted : "",
                  ]
                    .filter(Boolean)
                    .join(" ")}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* ── Step content ─────────────────────────────────────────────────── */}
      <div className={styles.stepContent}>
        {currentStep === "auth" && (
          <AuthStep
            onSubmit={handleAuth}
            submitting={submitting}
            error={errors.auth}
          />
        )}
        {currentStep === "monday" && (
          <MondayStep
            onConnect={handleMondayConnect}
            submitting={submitting}
            error={errors.monday}
          />
        )}
        {currentStep === "freshsales" && (
          <FreshsalesStep
            onConnect={handleFreshsalesConnect}
            submitting={submitting}
            error={errors.freshsales}
          />
        )}
        {currentStep === "templates" && (
          <TemplatesStep
            onInstall={handleInstallTemplates}
            submitting={submitting}
            error={errors.templates}
          />
        )}
      </div>
    </div>
  );
};

// ─── AuthStep ────────────────────────────────────────────────────────────────

interface AuthStepProps {
  onSubmit: (
    domain: string,
    email: string,
    password: string,
    isLogin: boolean,
    name?: string,
    website?: string,
  ) => Promise<void>;
  submitting: boolean;
  error: string;
}

const AuthStep: React.FC<AuthStepProps> = ({ onSubmit, submitting, error }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [domain, setDomain] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [website, setWebsite] = useState("");
  const [localError, setLocalError] = useState("");

  const validate = () => {
    if (!domain.trim()) return "Domain is required";
    if (!/^[a-z0-9-]+$/.test(domain)) return "Domain must be lowercase letters, numbers and hyphens only";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Invalid email address";
    if (password.length < 8) return "Password must be at least 8 characters";
    if (!isLogin && !name.trim()) return "Name is required";
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError("");
    const validationError = validate();
    if (validationError) {
      setLocalError(validationError);
      return;
    }
    await onSubmit(domain, email, password, isLogin, name, website);
  };

  const displayError = localError || error;

  const getFn = async(e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res:any = await monday.storage.getItem('mykey');
      console.log("siva get",res);
      console.log("monday", monday);

    } catch (error) {
      console.log("error in get", error);
    }
  } 
  
  const setFn = async(e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = JSON.stringify({
        name:"siva",
        role: "dev",
        city: "chennai"
      });
      const res:any = await monday.storage.setItem('mykey', "this is a test data");
      console.log("siva set",res);
    } catch (error) {
      console.log("error in set", error);
    }
  } 

  return (
    <div className={styles.stepPanel}>
      <div className={styles.panelHeader}>
        <button id="setBtn" onClick={setFn}>set</button>
        <button id="getBtn" onClick={getFn}>get</button>
        <h2 className={styles.panelTitle}>
          {isLogin ? "Welcome Back" : "Create Account"}
        </h2>
        <p className={styles.panelSubtitle}>
          {isLogin
            ? "Sign in to your Konnectify workspace"
            : "Set up your Konnectify workspace"}
        </p>
      </div>

      {displayError && (
        <div className={styles.errorAlert}>
          <Warning size={16} />
          <span>{displayError}</span>
        </div>
      )}

      <form onSubmit={(e) => void handleSubmit(e)} className={styles.form}>
        <div className={styles.formGroup}>
          <label className={styles.formLabel}>Konnectify Domain</label>
          <div className={styles.inputWrapper}>
            <Globe size={18} />
            <input
              type="text"
              placeholder="your-domain"
              value={domain}
              onChange={(e) => setDomain(e.target.value.toLowerCase())}
              disabled={submitting}
            />
            <span className={styles.domainSuffix}>.konnectifyapp.co</span>
          </div>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.formLabel}>Email Address</label>
          <div className={styles.inputWrapper}>
            <Email size={18} />
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={submitting}
            />
          </div>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.formLabel}>Password</label>
          <div className={styles.inputWrapper}>
            <Locked size={18} />
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={submitting}
            />
          </div>
        </div>

        {!isLogin && (
          <>
            <div className={styles.formGroup}>
              <label className={styles.formLabel}>Full Name</label>
              <div className={styles.inputWrapper}>
                <Person size={18} />
                <input
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={submitting}
                />
              </div>
            </div>

            <div className={styles.formGroup}>
              <label className={styles.formLabel}>
                Company Website{" "}
                <span className={styles.optional}>(optional)</span>
              </label>
              <div className={styles.inputWrapper}>
                <Globe size={18} />
                <input
                  type="url"
                  placeholder="https://example.com"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  disabled={submitting}
                />
              </div>
            </div>
          </>
        )}

        <Button
          kind="primary"
          type="submit"
          loading={submitting}
          disabled={submitting}
          style={{ width: "100%", marginTop: 8 }}
        >
          {isLogin ? "Sign In" : "Create Account"}
        </Button>

        <div className={styles.toggleAuth}>
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <button
            type="button"
            className={styles.toggleLink}
            onClick={() => {
              setIsLogin(!isLogin);
              setLocalError("");
            }}
            disabled={submitting}
          >
            {isLogin ? "Create one" : "Sign in"}
          </button>
        </div>
      </form>
    </div>
  );
};

// ─── MondayStep ──────────────────────────────────────────────────────────────

interface MondayStepProps {
  onConnect: (apiToken: string) => Promise<void>;
  submitting: boolean;
  error: string;
}

const MondayStep: React.FC<MondayStepProps> = ({ onConnect, submitting, error }) => {
  const [apiToken, setApiToken] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("siva on click", apiToken);
    await onConnect(apiToken);
  };

  return (
    <div className={styles.stepPanel}>
      <div className={styles.panelHeader}>
        <h2 className={styles.panelTitle}>Connect Monday</h2>
        <p className={styles.panelSubtitle}>
          Enter your Monday.com API token to link your account
        </p>
      </div>

      {error && (
        <div className={styles.errorAlert}>
          <Warning size={16} />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={(e) => void handleSubmit(e)} className={styles.form}>
        <div className={styles.formGroup}>
          <label className={styles.formLabel}>Monday.com API Token</label>
          <div className={styles.inputWrapper}>
            <Locked size={18} />
            <input
              type="password"
              placeholder="Paste your API token here…"
              value={apiToken}
              onChange={(e) => setApiToken(e.target.value)}
              disabled={submitting}
            />
          </div>
          <Text type="text3" color="secondary" style={{ marginTop: 4 }}>
            Find your token in Monday.com → Profile → Developers → API Tokens
          </Text>
        </div>

        <Button
          kind="primary"
          type="submit"
          loading={submitting}
          disabled={submitting || !apiToken.trim()}
          style={{ width: "100%", marginTop: 8 }}
        >
          Connect Monday
        </Button>
      </form>
    </div>
  );
};

// ─── FreshsalesStep ──────────────────────────────────────────────────────────

interface FreshsalesStepProps {
  onConnect: (domain: string, apiKey: string) => Promise<void>;
  submitting: boolean;
  error: string;
}

const FreshsalesStep: React.FC<FreshsalesStepProps> = ({ onConnect, submitting, error }) => {
  const [domain, setDomain] = useState("");
  const [apiKey, setApiKey] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onConnect(domain.trim(), apiKey.trim());
  };

  return (
    <div className={styles.stepPanel}>
      <div className={styles.panelHeader}>
        <h2 className={styles.panelTitle}>Connect Freshsales</h2>
        <p className={styles.panelSubtitle}>
          Enter your Freshsales domain and API key to link your account
        </p>
      </div>

      {error && (
        <div className={styles.errorAlert}>
          <Warning size={16} />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={(e) => void handleSubmit(e)} className={styles.form}>
        <div className={styles.formGroup}>
          <label className={styles.formLabel}>Freshsales Domain</label>
          <div className={styles.inputWrapper}>
            <Globe size={18} />
            <input
              type="text"
              placeholder="yourcompany"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              disabled={submitting}
            />
            <span className={styles.domainSuffix}>.myfreshworks.com</span>
          </div>
          <Text type="text3" color="secondary" style={{ marginTop: 4 }}>
            Enter just the subdomain, e.g. "yourcompany" for yourcompany.myfreshworks.com
          </Text>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.formLabel}>API Key</label>
          <div className={styles.inputWrapper}>
            <Locked size={18} />
            <input
              type="password"
              placeholder="Paste your API key here…"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              disabled={submitting}
            />
          </div>
          <Text type="text3" color="secondary" style={{ marginTop: 4 }}>
            Find your API key in Freshsales → Settings → API Settings
          </Text>
        </div>

        <Button
          kind="primary"
          type="submit"
          loading={submitting}
          disabled={submitting || !domain.trim() || !apiKey.trim()}
          style={{ width: "100%", marginTop: 8 }}
        >
          Connect Freshsales
        </Button>
      </form>
    </div>
  );
};

// ─── TemplatesStep ───────────────────────────────────────────────────────────

interface TemplatesStepProps {
  onInstall: () => Promise<void>;
  submitting: boolean;
  error: string;
}

const TemplatesStep: React.FC<TemplatesStepProps> = ({
  onInstall,
  submitting,
  error,
}) => (
  <div className={styles.stepPanel}>
    <div className={styles.panelHeader}>
      <h2 className={styles.panelTitle}>Install Workflow Templates</h2>
      <p className={styles.panelSubtitle}>
        Pre-built workflows to get you started instantly
      </p>
    </div>

    {error && (
      <div className={styles.errorAlert}>
        <Warning size={16} />
        <span>{error}</span>
      </div>
    )}

    <div className={styles.form}>
      <div className={styles.templateInfo}>
        <div className={styles.infoIcon}>
          <Check size={20} />
        </div>
        <div>
          <p className={styles.infoTitle}>Ready to Install</p>
          <p className={styles.infoText}>
            Two workflow templates will be installed:
            <br />• <strong>Contact Sync</strong> — Freshsales ↔ Monday contacts
           
          </p>
        </div>
      </div>

      <Button
        kind="primary"
        onClick={() => void onInstall()}
        loading={submitting}
        disabled={submitting}
        style={{ width: "100%", marginTop: 8 }}
      >
        Install Templates
      </Button>
    </div>
  </div>
);

// ─── CompleteStep ────────────────────────────────────────────────────────────

const CompleteStep: React.FC = () => {
  const { client, tenant, auth, connections, refreshConnections, logout } = useKonnectify();
  console.log("siva connections", connections);
  const mondayConn = connections.find((c) => c.appId === APP_IDS.monday) ?? null;
  console.log("siva Monday connection", mondayConn);
  const freshsalesConn = connections.find((c) => c.appId === APP_IDS.freshsales) ?? null;

  return (
    <div className={styles.stepPanel} style={{ maxWidth: 600 }}>
      {/* Header */}
      <div className={styles.panelHeader}>
        <div className={styles.completeIcon} style={{ marginBottom: 8 }}>
          <Check size={36} />
        </div>
        <h2 className={styles.completeTitle} style={{ fontSize: 22 }}>Setup Complete</h2>
        <p className={styles.panelSubtitle}>
          Your Konnectify workspace is fully configured. Open the{" "}
          <strong style={{ color: "var(--text-primary)" }}>Board View</strong> tab to manage your konnectors.
        </p>
      </div>

      {/* Account info */}
      <div className={styles.infoSection}>
        <p className={styles.sectionLabel}>Account</p>
        <div className={styles.infoGrid}>
          <span className={styles.infoKey}>Domain</span>
          <span className={styles.infoVal}>{tenant?.domain}</span>
          <span className={styles.infoKey}>Email</span>
          <span className={styles.infoVal}>{auth?.email}</span>
        </div>
      </div>

      {/* Connections */}
      <div className={styles.infoSection}>
        <p className={styles.sectionLabel}>Connections</p>
        <ConnectionEditCard
          label="Monday.com"
          connection={mondayConn}
          fields={[{ key: "api_key", label: "API Token", type: "password" }]}
          appId={APP_IDS.monday}
          connectionName="Monday Connection"
          client={client}
          onSaved={() => void refreshConnections()}
        />
        <ConnectionEditCard
          label="Freshsales"
          connection={freshsalesConn}
          fields={[
            { key: "domain", label: "Domain", type: "text", suffix: ".freshsales.io" },
            { key: "api_key", label: "API Key", type: "password" },
          ]}
          appId={APP_IDS.freshsales}
          connectionName="Freshsales Connection"
          client={client}
          onSaved={() => void refreshConnections()}
        />
      </div>

      <button
        className={styles.toggleLink}
        style={{ marginTop: 8 }}
        onClick={() => { if (confirm("Are you sure you want to logout?")) void logout(); }}
      >
        Logout
      </button>
    </div>
  );
};

// ─── ConnectionEditCard ───────────────────────────────────────────────────────

import type { Connection } from "../../types";
import type { KonnectifyClient } from "../../services/konnectifyClient";

interface FieldDef {
  key: string;
  label: string;
  type: "text" | "password";
  suffix?: string;
}

interface ConnectionEditCardProps {
  label: string;
  connection: Connection | null;
  fields: FieldDef[];
  appId: string;
  connectionName: string;
  client: KonnectifyClient | null;
  onSaved: () => void;
}

const ConnectionEditCard: React.FC<ConnectionEditCardProps> = ({
  label,
  connection,
  fields,
  appId,
  connectionName,
  client,
  onSaved,
}) => {
  const [editing, setEditing] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const startEdit = () => {
    // Pre-fill with existing data where available (api_key is never returned by API)
    const prefilled: Record<string, string> = {};
    fields.forEach((f) => {
      prefilled[f.key] = (connection?.data?.[f.key] as string | undefined) ?? "";
    });
    setValues(prefilled);
    setError("");
    setEditing(true);
  };

  const handleSave = async () => {
    if (!client) return;
    setError("");
    setSaving(true);
    try {
      const data: Record<string, unknown> = {};
      fields.forEach((f) => { data[f.key] = values[f.key]; });

      if (connection) {
        await connectionService.edit(client, connection.id, appId, connection.name, data);
      } else {
        await connectionService.create(client, appId, connectionName, data);
      }
      onSaved();
      setEditing(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={styles.connCard}>
      <div className={styles.connCardHeader}>
        <div>
          <span className={styles.connLabel}>{label}</span>
          {connection ? (
            <span className={styles.connStatus}>Connected</span>
          ) : (
            <span className={styles.connStatusMissing}>Not connected</span>
          )}
        </div>
        {!editing && (
          <button className={styles.editLink} onClick={startEdit}>
            {connection ? "Edit" : "Connect"}
          </button>
        )}
      </div>

      {editing && (
        <div className={styles.connForm}>
          {error && (
            <div className={styles.errorAlert} style={{ marginBottom: 12 }}>
              <Warning size={14} />
              <span>{error}</span>
            </div>
          )}
          {fields.map((f) => (
            <div key={f.key} className={styles.formGroup}>
              <label className={styles.formLabel}>{f.label}</label>
              <div className={styles.inputWrapper}>
                <Locked size={16} />
                <input
                  type={f.type}
                  placeholder={f.type === "password" ? "••••••••" : f.label}
                  value={values[f.key] ?? ""}
                  onChange={(e) => setValues((prev) => ({ ...prev, [f.key]: e.target.value }))}
                  disabled={saving}
                />
                {f.suffix && <span className={styles.domainSuffix}>{f.suffix}</span>}
              </div>
            </div>
          ))}
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <Button kind="primary" size="small" loading={saving} onClick={() => void handleSave()}>
              Save
            </Button>
            <Button kind="tertiary" size="small" disabled={saving} onClick={() => setEditing(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
